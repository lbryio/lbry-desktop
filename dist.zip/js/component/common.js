'use strict';

//component/icon.js

var Icon = React.createClass({
  displayName: 'Icon',

  propTypes: {
    style: React.PropTypes.object
  },
  render: function render() {
    var className = 'icon ' + this.props.icon;
    return React.createElement('span', { className: className, style: this.props.style });
  }
});

var Link = React.createClass({
  displayName: 'Link',

  render: function render() {
    console.log(this.props);
    var href = this.props.href ? this.props.href : 'javascript:;',
        icon = this.props.icon ? React.createElement(Icon, { icon: this.props.icon }) : '',
        className = this.props.button ? 'button-block button-' + this.props.button : 'button-text';
    return React.createElement(
      'a',
      { className: className, href: href, style: this.props.style ? this.props.style : {}, onClick: this.props.onClick },
      this.props.icon ? icon : '',
      this.props.label
    );
  }
});

var creditAmountStyle = {
  color: '#216C2A',
  fontWeight: 'bold',
  fontSize: '0.8em'
},
    estimateStyle = {
  marginLeft: '5px',
  color: '#aaa'
};

var CreditAmount = React.createClass({
  displayName: 'CreditAmount',

  propTypes: {
    amount: React.PropTypes.number
  },
  render: function render() {
    var formattedAmount = lbry.formatCredits(this.props.amount);
    return React.createElement(
      'span',
      { className: 'credit-amount' },
      React.createElement(
        'span',
        { style: creditAmountStyle },
        formattedAmount
      ),
      this.props.isEstimate ? React.createElement(
        'span',
        { style: estimateStyle },
        '(est)'
      ) : null
    );
  }
});