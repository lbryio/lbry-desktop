'use strict';

//component/icon.js

var Icon = React.createClass({
  displayName: 'Icon',

  propTypes: {
    style: React.PropTypes.object,
    fixed: React.PropTypes.boolean
  },
  render: function render() {
    var className = 'icon ' + ('fixed' in this.props ? 'icon-fixed-width ' : '') + this.props.icon;
    return React.createElement('span', { className: className, style: this.props.style });
  }
});

var Link = React.createClass({
  displayName: 'Link',

  render: function render() {
    console.log(this.props);
    var href = this.props.href ? this.props.href : 'javascript:;',
        icon = this.props.icon ? React.createElement(Icon, { icon: this.props.icon }) : '',
        className = (this.props.button ? 'button-block button-' + this.props.button : 'button-text') + (this.props.hidden ? ' hidden' : '') + (this.props.disabled ? ' disabled' : '');
    return React.createElement(
      'a',
      { className: className, href: href, style: this.props.style ? this.props.style : {},
        title: this.props.title, onClick: this.props.onClick },
      this.props.icon ? icon : '',
      this.props.label
    );
  }
});

var DownloadLink = React.createClass({
  displayName: 'DownloadLink',

  propTypes: {
    type: React.PropTypes.string,
    streamName: React.PropTypes.string,
    label: React.PropTypes.string,
    downloadingLabel: React.PropTypes.string,
    button: React.PropTypes.string,
    style: React.PropTypes.object,
    hidden: React.PropTypes.bool
  },
  getDefaultProps: function getDefaultProps() {
    return {
      icon: 'icon-download',
      label: 'Download',
      downloadingLabel: 'Downloading...'
    };
  },
  getInitialState: function getInitialState() {
    return {
      downloading: false
    };
  },
  startDownload: function startDownload() {
    if (!this.state.downloading) {
      //@TODO: Continually update this.state.downloading based on actual status of file
      this.setState({
        downloading: true
      });

      lbry.getStream(this.props.streamName, function (streamInfo) {
        alert('Downloading to ' + streamInfo.path);
        console.log(streamInfo);
      });
    }
  },
  render: function render() {
    var label = !this.state.downloading ? this.props.label : this.props.downloadingLabel;
    return React.createElement(Link, { button: this.props.button, hidden: this.props.hidden, style: this.props.style,
      disabled: this.state.downloading, label: label, icon: this.props.icon, onClick: this.startDownload });
  }
});

var WatchLink = React.createClass({
  displayName: 'WatchLink',

  propTypes: {
    type: React.PropTypes.string,
    streamName: React.PropTypes.string,
    label: React.PropTypes.string,
    button: React.PropTypes.string,
    style: React.PropTypes.object,
    hidden: React.PropTypes.bool
  },

  getDefaultProps: function getDefaultProps() {
    return {
      icon: 'icon-play',
      label: 'Watch'
    };
  },

  render: function render() {
    // No support for lbry:// URLs in Windows or on Chrome yet
    if (/windows|win32/i.test(navigator.userAgent) || window.chrome && window.navigator.vendor == "Google Inc.") {
      var uri = "/?watch=" + this.props.streamName;
    } else {
      var uri = 'lbry://' + this.props.streamName;
    }
    return React.createElement(Link, { button: this.props.button, hidden: this.props.hidden, style: this.props.style,
      href: uri, label: this.props.label, icon: this.props.icon, onClick: this.onClick });
  }
});

// Generic menu styles
var menuStyle = {
  border: '1px solid #aaa',
  padding: '4px',
  whiteSpace: 'nowrap'
};

var Menu = React.createClass({
  displayName: 'Menu',

  handleWindowClick: function handleWindowClick(e) {
    if (this.props.toggleButton && ReactDOM.findDOMNode(this.props.toggleButton).contains(e.target)) {
      // Toggle button was clicked
      this.setState({
        open: !this.state.open
      });
    } else if (this.state.open && !this.refs.div.contains(e.target)) {
      // Menu is open and user clicked outside of it
      this.setState({
        open: false
      });
    }
  },
  propTypes: {
    openButton: React.PropTypes.element
  },
  getInitialState: function getInitialState() {
    return {
      open: false
    };
  },
  componentDidMount: function componentDidMount() {
    window.addEventListener('click', this.handleWindowClick, false);
  },
  componentWillUnmount: function componentWillUnmount() {
    window.removeEventListener('click', this.handleWindowClick, false);
  },
  render: function render() {
    return React.createElement(
      'div',
      { ref: 'div', style: menuStyle, className: this.state.open ? '' : 'hidden' },
      this.props.children
    );
  }
});

var menuItemStyle = {
  display: 'block'
};
var MenuItem = React.createClass({
  displayName: 'MenuItem',

  propTypes: {
    href: React.PropTypes.string,
    label: React.PropTypes.string,
    icon: React.PropTypes.string,
    onClick: React.PropTypes.function
  },
  getDefaultProps: function getDefaultProps() {
    return {
      iconPosition: 'left'
    };
  },
  render: function render() {
    var icon = this.props.icon ? React.createElement(Icon, { icon: this.props.icon, fixed: true }) : null;

    return React.createElement(
      'a',
      { style: menuItemStyle, href: this.props.href, label: this.props.label, title: this.props.label,
        className: 'button-text no-underline' },
      this.props.iconPosition == 'left' ? icon : null,
      this.props.label,
      this.props.iconPosition == 'left' ? null : icon
    );
  }
});

var creditAmountStyle = {
  color: '#216C2A',
  fontWeight: 'bold',
  fontSize: '0.8em'
},
    estimateStyle = {
  marginLeft: '5px',
  color: '#aaa'
};

var CreditAmount = React.createClass({
  displayName: 'CreditAmount',

  propTypes: {
    amount: React.PropTypes.number
  },
  render: function render() {
    var formattedAmount = lbry.formatCredits(this.props.amount);
    return React.createElement(
      'span',
      { className: 'credit-amount' },
      React.createElement(
        'span',
        { style: creditAmountStyle },
        formattedAmount
      ),
      this.props.isEstimate ? React.createElement(
        'span',
        { style: estimateStyle },
        '(est)'
      ) : null
    );
  }
});

var subPageLogoStyle = {
  maxWidth: '150px',
  display: 'block',
  marginTop: '36px'
};

var SubPageLogo = React.createClass({
  displayName: 'SubPageLogo',

  render: function render() {
    return React.createElement('img', { src: 'img/lbry-dark-1600x528.png', style: subPageLogoStyle });
  }
});