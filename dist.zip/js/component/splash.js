'use strict';

var splashStyle = {
  color: 'white',
  backgroundImage: 'url(' + lbry.imagePath('lbry-bg.png') + ')',
  backgroundSize: 'cover',
  minHeight: '100vh',
  minWidth: '100vw',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center'
},
    splashMessageStyle = {
  marginTop: '24px',
  width: '325px',
  textAlign: 'center'
};

var SplashScreen = React.createClass({
  displayName: 'SplashScreen',

  propTypes: {
    message: React.PropTypes.string,
    onLoadDone: React.PropTypes.func
  },
  getInitialState: function getInitialState() {
    return {
      details: 'Starting daemon',
      isLagging: false
    };
  },
  updateStatus: function updateStatus() {
    var _this = this;

    var was_lagging = arguments.length <= 0 || arguments[0] === undefined ? false : arguments[0];

    lbry.getDaemonStatus(function (status) {
      if (status.code == 'started') {
        _this.props.onLoadDone();
        return;
      }

      _this.setState({
        details: status.message + (status.is_lagging ? '' : '...'),
        isLagging: status.is_lagging
      });

      setTimeout(function () {
        _this.updateStatus(status.is_lagging);
      }, 500);
    });
  },
  componentDidMount: function componentDidMount() {
    this.updateStatus();
  },
  render: function render() {
    var imgSrc = lbry.imagePath('lbry-white-485x160.png');
    return React.createElement(
      'div',
      { className: 'splash-screen', style: splashStyle },
      React.createElement('img', { src: imgSrc, alt: 'LBRY' }),
      React.createElement(
        'div',
        { style: splashMessageStyle },
        React.createElement(
          'h3',
          null,
          this.props.message,
          React.createElement('span', { className: 'busy-indicator' })
        ),
        React.createElement(Icon, { icon: 'icon-warning', style: this.state.isLagging ? {} : { display: 'none' } }),
        ' ',
        React.createElement(
          'span',
          { style: this.state.isLagging ? {} : { 'color': '#c3c3c3' } },
          this.state.details
        )
      )
    );
  }
});