'use strict';

var splashStyle = {
  color: 'white',
  backgroundImage: 'url(' + lbry.imagePath('lbry-bg.png') + ')',
  backgroundSize: 'cover',
  minHeight: '100vh',
  minWidth: '100vw',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center'
},
    splashMessageStyle = {
  marginTop: '24px'
};

var SplashScreen = React.createClass({
  displayName: 'SplashScreen',

  propTypes: {
    message: React.PropTypes.string
  },
  render: function render() {
    var imgSrc = lbry.imagePath('lbry-white-485x160.png');
    return React.createElement(
      'div',
      { className: 'splash-screen', style: splashStyle },
      React.createElement('img', { src: imgSrc, alt: 'LBRY' }),
      React.createElement(
        'div',
        { style: splashMessageStyle },
        React.createElement(
          'h3',
          null,
          this.props.message,
          React.createElement('span', { className: 'busy-indicator' })
        )
      )
    );
  }
});