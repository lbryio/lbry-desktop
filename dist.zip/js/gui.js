'use strict';

//component/icon.js

var Icon = React.createClass({
  displayName: 'Icon',

  render: function render() {
    var className = 'icon ' + this.props.icon;
    return React.createElement('span', { className: className });
  }
});

//component/link.js

var Link = React.createClass({
  displayName: 'Link',

  render: function render() {
    console.log(this.props);
    var href = this.props.href ? this.props.href : 'javascript:;',
        icon = this.props.icon ? React.createElement(Icon, { icon: this.props.icon }) : '',
        className = this.props.button ? 'button-block button-' + this.props.button : 'button-text';
    return React.createElement(
      'a',
      { className: className, href: href },
      this.props.icon ? icon : '',
      this.props.label
    );
  }
});

//component/splash.js
var splashStyle = {
  color: 'white',
  backgroundImage: 'url(' + lbry.imagePath('lbry-bg.png') + ')',
  backgroundSize: 'cover',
  minHeight: '100vh',
  minWidth: '100vw',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center'
},
    splashMessageStyle = {
  marginTop: '24px'
};

var SplashScreen = React.createClass({
  displayName: 'SplashScreen',

  propTypes: {
    message: React.PropTypes.string
  },
  render: function render() {
    var imgSrc = lbry.imagePath('lbry-white-485x160.png');
    return React.createElement(
      'div',
      { className: 'splash-screen', style: splashStyle },
      React.createElement('img', { src: imgSrc, alt: 'LBRY' }),
      React.createElement(
        'div',
        { style: splashMessageStyle },
        React.createElement(
          'h3',
          null,
          this.props.message,
          React.createElement('span', { className: 'busy-indicator' })
        )
      )
    );
  }
});

//component/credit-amount.js
var creditAmountStyle = {
  color: '#216C2A',
  fontWeight: 'bold',
  fontSize: '0.8em'
},
    estimateStyle = {
  marginLeft: '5px',
  color: '#aaa'
};

var CreditAmount = React.createClass({
  displayName: 'CreditAmount',

  propTypes: {
    amount: React.PropTypes.number
  },
  render: function render() {
    var formattedAmount = lbry.formatCredits(this.props.amount);
    return React.createElement(
      'span',
      { className: 'credit-amount' },
      React.createElement(
        'span',
        { style: creditAmountStyle },
        formattedAmount
      ),
      this.props.isEstimate ? React.createElement(
        'span',
        { style: estimateStyle },
        '(est)'
      ) : null
    );
  }
});

//component/header.js
var logoStyle = {
  padding: '48px 12px',
  textAlign: 'center',
  maxHeight: '80px'
},
    balanceStyle = {
  float: 'right',
  marginTop: '3px'
},
    imgStyle = { //@TODO: remove this, img should be properly scaled once size is settled
  height: '80px'
};

var Header = React.createClass({
  displayName: 'Header',

  getInitialState: function getInitialState() {
    return {
      balance: 0
    };
  },
  componentDidMount: function componentDidMount() {
    lbry.getBalance(function (balance) {
      this.setState({
        balance: balance
      });
    }.bind(this));
  },
  render: function render() {
    return React.createElement(
      'header',
      null,
      React.createElement(
        'span',
        { style: balanceStyle },
        React.createElement(CreditAmount, { amount: this.state.balance })
      ),
      React.createElement(
        'div',
        { style: logoStyle },
        React.createElement('img', { src: './img/lbry-dark-1600x528.png', style: imgStyle })
      )
    );
  }
});

//component/discover.js

var searchInputStyle = {
  width: '400px',
  display: 'block',
  marginBottom: '48px',
  marginLeft: 'auto',
  marginRight: 'auto'
},
    fetchResultsStyle = {
  color: '#888',
  textAlign: 'center',
  fontSize: '1.2em'
};

var SearchActive = React.createClass({
  displayName: 'SearchActive',

  render: function render() {
    return React.createElement(
      'section',
      { style: fetchResultsStyle },
      'Looking up the Dewey Decimals',
      React.createElement('span', { className: 'busy-indicator' })
    );
  }
});

var searchNoResultsStyle = {
  textAlign: 'center'
},
    searchNoResultsMessageStyle = {
  fontStyle: 'italic',
  marginRight: '5px'
};

var SearchNoResults = React.createClass({
  displayName: 'SearchNoResults',

  render: function render() {
    return React.createElement(
      'section',
      { style: searchNoResultsStyle },
      React.createElement(
        'span',
        { style: searchNoResultsMessageStyle },
        'No one has checked anything in for ',
        this.props.query,
        ' yet.'
      ),
      React.createElement(Link, { label: 'Be the first', href: 'javascript:alert(\'aww I do nothing\')' })
    );
  }
});

var SearchResults = React.createClass({
  displayName: 'SearchResults',

  render: function render() {
    var rows = [];
    console.log('results');
    this.props.results.forEach(function (result) {
      rows.push(React.createElement(SearchResultRow, { name: result.name, title: result.title, imgUrl: result.thumbnail,
        description: result.description, cost_est: result.cost_est }));
    });
    console.log(this.props.results);
    console.log(rows);
    console.log('done');
    return React.createElement(
      'section',
      null,
      rows
    );
  }
});

var searchRowImgStyle = {
  maxHeight: '100px',
  display: 'block',
  marginLeft: 'auto',
  marginRight: 'auto',
  float: 'left'
},
    searchRowCostStyle = {
  float: 'right',
  marginLeft: '20px',
  marginTop: '5px',
  display: 'inline-block'
},
    searchRowNameStyle = {
  fontSize: '0.9em',
  color: '#666',
  marginBottom: '24px',
  clear: 'both'
},
    searchRowDescriptionStyle = {
  color: '#444',
  marginBottom: '24px',
  fontSize: '0.9em'
};

var SearchResultRow = React.createClass({
  displayName: 'SearchResultRow',

  render: function render() {
    var uri = 'lbry://' + this.props.name;
    return React.createElement(
      'div',
      { className: 'row-fluid' },
      React.createElement(
        'div',
        { className: 'span3' },
        React.createElement('img', { src: this.props.imgUrl, alt: 'Photo for {this.props.title}', style: searchRowImgStyle })
      ),
      React.createElement(
        'div',
        { className: 'span9' },
        React.createElement(
          'span',
          { style: searchRowCostStyle },
          React.createElement(CreditAmount, { amount: this.props.cost_est, isEstimate: true })
        ),
        React.createElement(
          'h2',
          null,
          this.props.title
        ),
        React.createElement(
          'div',
          { style: searchRowNameStyle },
          uri
        ),
        React.createElement(
          'p',
          { style: searchRowDescriptionStyle },
          this.props.description
        ),
        React.createElement(
          'div',
          null,
          React.createElement(Link, { href: uri, label: 'Watch', icon: 'icon-play', button: 'primary' }),
          React.createElement(Link, { href: uri, label: 'Download', icon: 'icon-download', button: 'alt' })
        )
      )
    );
  }
});

var discoverMainStyle = {
  color: '#333'
};

var Discover = React.createClass({
  displayName: 'Discover',

  userTypingTimer: null,

  getInitialState: function getInitialState() {
    return {
      results: [],
      searching: false,
      query: ''
    };
  },

  search: function search() {
    if (this.state.query) {
      console.log('search');
      lbry.search(this.state.query, this.searchCallback.bind(this, this.state.query));
    } else {
      this.setState({
        searching: false,
        results: []
      });
    }
  },

  searchCallback: function searchCallback(originalQuery, results) {
    if (this.state.searching) //could have canceled while results were pending, in which case nothing to do
      {
        this.setState({
          results: results,
          searching: this.state.query != originalQuery });
      }
  },

  //multiple searches can be out, we're only done if we receive one we actually care about
  onQueryChange: function onQueryChange(event) {
    if (this.userTypingTimer) {
      clearTimeout(this.userTypingTimer);
    }

    //@TODO: Switch to React.js timing
    this.userTypingTimer = setTimeout(this.search, 800); // 800ms delay, tweak for faster/slower

    this.setState({
      searching: event.target.value.length > 0,
      query: event.target.value
    });
  },

  render: function render() {
    console.log(this.state);
    return React.createElement(
      'main',
      { style: discoverMainStyle },
      React.createElement(
        'section',
        null,
        React.createElement('input', { type: 'search', style: searchInputStyle, onChange: this.onQueryChange,
          placeholder: 'Find movies, music, games, and more' })
      ),
      this.state.searching ? React.createElement(SearchActive, null) : null,
      !this.state.searching && this.state.results.length ? React.createElement(SearchResults, { results: this.state.results }) : null,
      !this.state.searching && !this.state.results.length && this.state.query ? React.createElement(SearchNoResults, { query: this.state.query }) : null
    );
  }
});

//component/home.js

var homeStyles = {
  width: '800px',
  marginLeft: 'auto',
  marginRight: 'auto'
};

var Home = React.createClass({
  displayName: 'Home',

  render: function render() {
    return React.createElement(
      'div',
      { style: homeStyles },
      React.createElement(Header, null),
      React.createElement(Discover, null)
    );
  }
});

//main.js
var init = function init() {
  var canvas = document.getElementById('canvas');

  ReactDOM.render(React.createElement(SplashScreen, { message: 'Connecting' }), canvas);

  lbry.connect(function () {
    ReactDOM.render(React.createElement(Home, null), canvas);
  });
};

init();