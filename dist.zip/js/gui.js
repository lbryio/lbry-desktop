"use strict";

//main.js
var init = function init() {
  var canvas = document.getElementById('canvas');

  ReactDOM.render(React.createElement(SplashScreen, { message: "Connecting" }), canvas);

  lbry.connect(function () {
    ReactDOM.render(React.createElement(App, null), canvas);
  });
};

init();