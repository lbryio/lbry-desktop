'use strict';

var claimCodePageStyle = {
  textAlign: 'center'
},
    claimCodeContentStyle = {
  display: 'inline-block',
  textAlign: 'left',
  width: '600px'
},
    claimCodeLabelStyle = {
  display: 'inline-block',
  cursor: 'default',
  width: '130px',
  textAlign: 'right',
  marginRight: '6px'
};

var ClaimCodePage = React.createClass({
  displayName: 'ClaimCodePage',

  getInitialState: function getInitialState() {
    return {
      submitting: false
    };
  },
  handleSubmit: function handleSubmit() {
    var _this = this;

    if (!this.refs.code.value) {
      alert('Please enter an invitation code or choose "Skip."');
      return;
    } else if (!this.refs.email.value) {
      alert('Please enter an email address or choose "Skip."');
      return;
    }

    this.setState({
      submitting: true
    });

    lbry.getNewAddress(function (address) {
      var code = _this.refs.code.value;
      var email = _this.refs.email.value;

      var xhr = new XMLHttpRequest();
      xhr.addEventListener('load', function () {
        var response = JSON.parse(xhr.responseText);

        if (response.success) {
          alert('Your invite code has been redeemed! The credits will be added to your balance shortly.');
          // Send them to "landing" instead of "home" (home will just trigger the message all over again until the credits arrive)
          window.location = '?landing';
        } else {
          alert("You've entered an invalid code, or one that's already been claimed. Please check your code and try again.");
          _this.setState({
            submitting: false
          });
        }
      });

      xhr.addEventListener('error', function () {
        _this.setState({
          submitting: false
        });
        alert('LBRY couldn\'t connect to our servers to confirm your invitation code. Please check your ' + 'internet connection. If you continue to have problems, you can still browse LBRY and ' + 'visit the Settings page to redeem your code later.');
      });

      xhr.open('POST', 'https://invites.lbry.io', true);
      xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
      xhr.send('code=' + encodeURIComponent(code) + '&address=' + encodeURIComponent(address) + '&email=' + encodeURIComponent(email));
    });
  },
  handleSkip: function handleSkip() {
    alert('Welcome to LBRY! You can visit the Settings page to redeem an invite code at any time.');
    window.location = '?landing';
  },
  render: function render() {
    return React.createElement(
      'main',
      { className: 'page', style: claimCodePageStyle },
      React.createElement(
        'h1',
        null,
        'Claim your beta invitation code'
      ),
      React.createElement(
        'section',
        { style: claimCodeContentStyle },
        React.createElement(
          'p',
          null,
          'Thanks for beta testing LBRY! Enter your invitation code and email address below to receive your initial LBRY credits.'
        ),
        React.createElement(
          'p',
          null,
          'You will be added to our mailing list (if you\'re not already on it) and will be eligible for future rewards for beta testers.'
        )
      ),
      React.createElement(
        'section',
        null,
        React.createElement(
          'form',
          { onSubmit: this.handleSubmit },
          React.createElement(
            'section',
            null,
            React.createElement(
              'label',
              { style: claimCodeLabelStyle, htmlFor: 'code' },
              'Invitation code'
            ),
            React.createElement('input', { name: 'code', ref: 'code' })
          ),
          React.createElement(
            'section',
            null,
            React.createElement(
              'label',
              { style: claimCodeLabelStyle, htmlFor: 'email' },
              'Email'
            ),
            React.createElement('input', { name: 'email', ref: 'email' })
          )
        )
      ),
      React.createElement(
        'section',
        null,
        React.createElement(Link, { button: 'primary', label: this.state.submitting ? "Submitting..." : "Submit",
          disabled: this.state.submitting, onClick: this.handleSubmit }),
        React.createElement(Link, { button: 'alt', label: 'Skip', disabled: this.state.submitting, onClick: this.handleSkip })
      )
    );
  }
});