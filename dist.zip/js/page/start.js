"use strict";

var StartPage = React.createClass({
  displayName: "StartPage",

  componentWillMount: function componentWillMount() {
    lbry.stop();
  },
  render: function render() {
    return React.createElement(
      "main",
      null,
      React.createElement(
        "h1",
        null,
        "LBRY is not running"
      ),
      React.createElement(Link, { href: "lbry://lbry", label: "Start LBRY" })
    );
  }
});