"use strict";

var HelpPage = React.createClass({
  displayName: "HelpPage",

  render: function render() {
    return React.createElement(
      "main",
      null,
      React.createElement(
        "h1",
        null,
        "Troubleshooting"
      ),
      React.createElement(
        "p",
        null,
        "Here are the most commonly encountered problems and what to try doing about them"
      ),
      React.createElement("br", null),
      React.createElement(
        "h3",
        null,
        "Nothing seems to start downloading"
      ),
      React.createElement(
        "p",
        null,
        "Not all content that you find in the search window is necessarily hosted, LBRY is still young. However, 'wonderfullife' should assuredly be accessible. If you can't download it, and you're not experiencing the below problem, try forwarding ports 4444 and 3333 on your firewall or router."
      ),
      React.createElement("br", null),
      React.createElement(
        "h3",
        null,
        "Videos have trouble playing"
      ),
      React.createElement(
        "p",
        null,
        "This is caused by your video player trying to start the file while it's still empty. Try reloading the page after a few seconds, it should work. You should also see the file appear in the downloads folder configured in your LBRY settings, which is the gear icon at the top of the main menu. A real fix for this is underway!"
      ),
      React.createElement("br", null),
      React.createElement(
        "h3",
        null,
        "How do I turn LBRY off?"
      ),
      React.createElement(
        "p",
        null,
        "If you're on OS X you can find the app running in your status bar, if you click the LBRY icon you'll have a 'Quit' button available. There is also a 'X' button in the browser main menu, either way works, the 'X' button is the default way to close LBRY on Linux. If you're running LBRY from the command line, you can use the above or you can run 'stop-lbrynet-daemon'"
      ),
      React.createElement("br", null),
      React.createElement(
        "h3",
        null,
        "None of this applies to me, or it didn't work"
      ),
      React.createElement(
        "p",
        null,
        React.createElement(Link, { href: "/report", label: "<< Click here to send us a bug report" }),
        React.createElement("br", null),
        React.createElement(Link, { href: "https://github.com/lbryio/lbry/issues", label: "<< Report an issue on github" })
      ),
      React.createElement("br", null),
      React.createElement("br", null),
      React.createElement(
        "section",
        null,
        React.createElement(Link, { href: "/", label: "<< Return" })
      )
    );
  }
});