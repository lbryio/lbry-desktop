'use strict';

var WatchPage = React.createClass({
  displayName: 'WatchPage',

  propTypes: {
    name: React.PropTypes.string
  },
  getInitialState: function getInitialState() {
    return {
      downloadStarted: false,
      readyToPlay: false,
      loadStatusMessage: "Requesting stream",
      mimeType: null
    };
  },
  componentDidMount: function componentDidMount() {
    lbry.getStream(this.props.name);
    this.updateLoadStatus();
  },
  updateLoadStatus: function updateLoadStatus() {
    var _this = this;

    lbry.getFileStatus(this.props.name, function (status) {
      if (!status || status.code != 'running' || status.written_bytes == 0) {
        // Download hasn't started yet, so update status message (if available) then try again
        if (status) {
          _this.setState({
            loadStatusMessage: status.message
          });
        }
        setTimeout(function () {
          _this.updateLoadStatus();
        }, 250);
      } else {
        _this.setState({
          readyToPlay: true,
          mimeType: status.mime_type
        });
        var player = new MediaElementPlayer(_this.refs.player, {
          mode: 'shim', // Force Flash (for now)
          setDimensions: false
        });
      }
    });
  },
  render: function render() {
    return React.createElement(
      'main',
      { className: 'page full-screen' },
      React.createElement(
        'div',
        { className: this.state.readyToPlay ? 'hidden' : '' },
        React.createElement(
          'h3',
          null,
          'Loading lbry://',
          this.props.name
        ),
        this.state.loadStatusMessage,
        '...'
      ),
      React.createElement(
        'video',
        { ref: 'player', width: '100%', height: '100%' },
        React.createElement('source', { type: this.state.mimeType == 'audio/m4a' || this.state.mimeType == 'audio/mp4a-latm' ? 'video/mp4' : this.state.mimeType, src: '/view?name=' + this.props.name })
      )
    );
  }
});