'use strict';

var videoStyle = {
  width: '100%',
  height: '100%',
  backgroundColor: '#000'
};

var WatchPage = React.createClass({
  displayName: 'WatchPage',

  propTypes: {
    name: React.PropTypes.string
  },
  getInitialState: function getInitialState() {
    return {
      downloadStarted: false,
      readyToPlay: false,
      loadStatusMessage: "Requesting stream"
    };
  },
  componentDidMount: function componentDidMount() {
    lbry.getStream(this.props.name);
    this.updateLoadStatus();
  },
  reloadIfNeeded: function reloadIfNeeded() {
    var _this = this;

    // Fallback option for loading problems: every 15 seconds, if the video hasn't reported being
    // playable yet, ask it to reload.
    if (!this.state.readyToPlay) {
      this._video.load();
      setTimeout(function () {
        _this.reloadIfNeeded();
      }, 15000);
    }
  },
  onCanPlay: function onCanPlay() {
    this.setState({
      readyToPlay: true
    });
  },
  updateLoadStatus: function updateLoadStatus() {
    var _this2 = this;

    lbry.getFileStatus(this.props.name, function (status) {
      if (!status || status.code != 'running' || status.written_bytes == 0) {
        // Download hasn't started yet, so update status message (if available) then try again
        if (status) {
          _this2.setState({
            loadStatusMessage: status.message
          });
        }
        setTimeout(function () {
          _this2.updateLoadStatus();
        }, 250);
      } else {
        _this2.setState({
          loadStatusMessage: "Buffering",
          downloadStarted: true
        });
        setTimeout(function () {
          _this2.reloadIfNeeded();
        }, 15000);
      }
    });
  },
  render: function render() {
    var _this3 = this;

    if (!this.state.downloadStarted) {
      var video = null;
    } else {
      // If the download has started, render the <video> behind the scenes so it can start loading.
      // When the video is actually ready to play, the loading text is hidden and the video shown.
      var video = React.createElement('video', { src: "/view?name=" + this.props.name, style: videoStyle,
        className: this.state.readyToPlay ? '' : 'hidden', controls: true,
        onCanPlay: this.onCanPlay, ref: function ref(video) {
          _this3._video = video;
        } });
    }

    return React.createElement(
      'main',
      null,
      React.createElement(
        'div',
        { className: this.state.readyToPlay ? 'hidden' : '' },
        React.createElement(
          'h3',
          null,
          'Loading lbry://',
          this.props.name
        ),
        this.state.loadStatusMessage,
        '...'
      ),
      video
    );
  }
});