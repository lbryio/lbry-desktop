'use strict';

var videoStyle = {
  width: '100%',
  height: '100%',
  backgroundColor: '#000'
};

var WatchPage = React.createClass({
  displayName: 'WatchPage',

  propTypes: {
    name: React.PropTypes.string
  },
  updateVideo: function updateVideo(video) {
    var _this = this;

    var firstRun = arguments.length <= 1 || arguments[1] === undefined ? true : arguments[1];

    if (!video.readyState) {
      if (!firstRun) {
        // On the first run, give the browser's initial load a chance to work
        video.load();
      }
      setTimeout(function () {
        _this.updateVideo(video, false);
      }, 3000);
    }
  },
  render: function render() {
    return React.createElement(
      'main',
      null,
      React.createElement('video', { style: videoStyle, src: "/view?name=" + this.props.name, ref: this.updateVideo, controls: true })
    );
  }
});