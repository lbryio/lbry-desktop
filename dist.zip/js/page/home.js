'use strict';

var searchInputStyle = {
  width: '400px',
  display: 'block',
  marginBottom: '48px',
  marginLeft: 'auto',
  marginRight: 'auto'
},
    fetchResultsStyle = {
  color: '#888',
  textAlign: 'center',
  fontSize: '1.2em'
};

var SearchActive = React.createClass({
  displayName: 'SearchActive',

  render: function render() {
    return React.createElement(
      'section',
      { style: fetchResultsStyle },
      'Looking up the Dewey Decimals',
      React.createElement('span', { className: 'busy-indicator' })
    );
  }
});

var searchNoResultsStyle = {
  textAlign: 'center'
},
    searchNoResultsMessageStyle = {
  fontStyle: 'italic',
  marginRight: '5px'
};

var SearchNoResults = React.createClass({
  displayName: 'SearchNoResults',

  render: function render() {
    return React.createElement(
      'section',
      { style: searchNoResultsStyle },
      React.createElement(
        'span',
        { style: searchNoResultsMessageStyle },
        'No one has checked anything in for ',
        this.props.query,
        ' yet.'
      ),
      React.createElement(Link, { label: 'Be the first', href: 'javascript:alert(\'aww I do nothing\')' })
    );
  }
});

var SearchResults = React.createClass({
  displayName: 'SearchResults',

  render: function render() {
    var rows = [];
    console.log('results');
    console.log('made it here');
    this.props.results.forEach(function (result) {
      rows.push(React.createElement(SearchResultRow, { name: result.name, title: result.title, imgUrl: result.thumbnail,
        description: result.description, cost_est: result.cost_est }));
    });
    console.log(this.props.results);
    console.log(rows);
    console.log('done');
    return React.createElement(
      'section',
      null,
      rows
    );
  }
});

var searchRowImgStyle = {
  maxHeight: '100px',
  display: 'block',
  marginLeft: 'auto',
  marginRight: 'auto',
  float: 'left'
},
    searchRowCostStyle = {
  float: 'right',
  marginLeft: '20px',
  marginTop: '5px',
  display: 'inline-block'
},
    searchRowNameStyle = {
  fontSize: '0.9em',
  color: '#666',
  marginBottom: '24px',
  clear: 'both'
},
    searchRowDescriptionStyle = {
  color: '#444',
  marginBottom: '24px',
  fontSize: '0.9em'
};

var SearchResultRow = React.createClass({
  displayName: 'SearchResultRow',

  getInitialState: function getInitialState() {
    return {
      downloading: false
    };
  },
  render: function render() {
    return React.createElement(
      'div',
      { className: 'row-fluid' },
      React.createElement(
        'div',
        { className: 'span3' },
        React.createElement('img', { src: this.props.imgUrl, alt: 'Photo for ' + (this.props.title || this.props.name), style: searchRowImgStyle })
      ),
      React.createElement(
        'div',
        { className: 'span9' },
        React.createElement(
          'span',
          { style: searchRowCostStyle },
          React.createElement(CreditAmount, { amount: this.props.cost_est, isEstimate: true })
        ),
        React.createElement(
          'h2',
          null,
          this.props.title
        ),
        React.createElement(
          'div',
          { style: searchRowNameStyle },
          'lbry://',
          this.props.name
        ),
        React.createElement(
          'p',
          { style: searchRowDescriptionStyle },
          this.props.description
        ),
        React.createElement(
          'div',
          null,
          React.createElement(WatchLink, { streamName: this.props.name, button: 'primary' }),
          React.createElement(DownloadLink, { streamName: this.props.name, button: 'alt' })
        )
      )
    );
  }
});

var featuredContentItemStyle = {
  fontSize: '0.95em',
  marginBottom: '10px'
},
    featuredContentItemImgStyle = {
  maxHeight: '90px',
  display: 'block',
  marginLeft: 'auto',
  marginRight: 'auto',
  marginTop: '5px',
  float: 'left'
},
    featuredContentItemDescriptionStyle = {
  color: '#444',
  marginBottom: '5px',
  fontSize: '0.9em'
},
    featuredContentItemCostStyle = {
  display: 'block',
  float: 'right',
  fontSize: '0.95em'
};

var FeaturedContentItem = React.createClass({
  displayName: 'FeaturedContentItem',

  propTypes: {
    name: React.PropTypes.string
  },
  getInitialState: function getInitialState() {
    return {
      metadata: null,
      title: null
    };
  },
  componentWillMount: function componentWillMount() {
    var _this = this;

    lbry.resolveName(this.props.name, function (metadata) {
      _this.setState({
        metadata: metadata,
        title: metadata.title || 'lbry://' + _this.props.name
      });
    });
  },
  render: function render() {
    if (this.state.metadata == null) {
      // Still waiting for metadata
      return null;
    }

    var metadata = this.state.metadata;

    return React.createElement(
      'div',
      { className: 'row-fluid', style: featuredContentItemStyle },
      React.createElement(
        'div',
        { className: 'span4' },
        React.createElement('img', { src: metadata.thumbnail, alt: 'Photo for ' + this.state.title, style: featuredContentItemImgStyle })
      ),
      React.createElement(
        'div',
        { className: 'span8' },
        React.createElement(
          'h4',
          null,
          this.state.title
        ),
        React.createElement(
          'p',
          { style: featuredContentItemDescriptionStyle },
          metadata.description
        ),
        React.createElement(
          'div',
          null,
          React.createElement(WatchLink, { streamName: this.props.name }),
          ' ',
          React.createElement(DownloadLink, { streamName: this.props.name }),
          React.createElement(
            'div',
            { style: featuredContentItemCostStyle },
            React.createElement(CreditAmount, { amount: 0.0, isEstimate: true })
          )
        )
      )
    );
  }
});

var featuredContentStyle = {
  width: '100%'
};

var FeaturedContent = React.createClass({
  displayName: 'FeaturedContent',

  render: function render() {
    return React.createElement(
      'section',
      { style: featuredContentStyle },
      React.createElement(
        'h3',
        null,
        'Featured content'
      ),
      React.createElement(
        'div',
        { className: 'row-fluid' },
        React.createElement(
          'div',
          { className: 'span6' },
          React.createElement(FeaturedContentItem, { name: 'wonderfullife' }),
          ' ',
          React.createElement(FeaturedContentItem, { name: 'wonderfullife' }),
          React.createElement(FeaturedContentItem, { name: 'wonderfullife' })
        ),
        React.createElement(
          'div',
          { className: 'span6' },
          React.createElement(FeaturedContentItem, { name: 'wonderfullife' }),
          React.createElement(FeaturedContentItem, { name: 'wonderfullife' }),
          React.createElement(FeaturedContentItem, { name: 'wonderfullife' })
        )
      )
    );
  }
});

var discoverMainStyle = {
  color: '#333'
};

var Discover = React.createClass({
  displayName: 'Discover',

  userTypingTimer: null,

  getInitialState: function getInitialState() {
    return {
      results: [],
      searching: false,
      query: ''
    };
  },

  search: function search() {
    if (this.state.query) {
      console.log('search');
      lbry.search(this.state.query, this.searchCallback.bind(this, this.state.query));
    } else {
      this.setState({
        searching: false,
        results: []
      });
    }
  },

  searchCallback: function searchCallback(originalQuery, results) {
    if (this.state.searching) //could have canceled while results were pending, in which case nothing to do
      {
        this.setState({
          results: results,
          searching: this.state.query != originalQuery });
      }
  },

  //multiple searches can be out, we're only done if we receive one we actually care about
  onQueryChange: function onQueryChange(event) {
    if (this.userTypingTimer) {
      clearTimeout(this.userTypingTimer);
    }

    //@TODO: Switch to React.js timing
    this.userTypingTimer = setTimeout(this.search, 800); // 800ms delay, tweak for faster/slower

    this.setState({
      searching: event.target.value.length > 0,
      query: event.target.value
    });
  },

  render: function render() {
    console.log(this.state);
    return React.createElement(
      'main',
      { style: discoverMainStyle },
      React.createElement(
        'section',
        null,
        React.createElement('input', { type: 'search', style: searchInputStyle, onChange: this.onQueryChange,
          placeholder: 'Find movies, music, games, and more' })
      ),
      this.state.searching ? React.createElement(SearchActive, null) : null,
      !this.state.searching && this.state.query && this.state.results.length ? React.createElement(SearchResults, { results: this.state.results }) : null,
      !this.state.searching && this.state.query && !this.state.results.length ? React.createElement(SearchNoResults, { query: this.state.query }) : null
    );
  }
});

var logoStyle = {
  padding: '48px 12px',
  textAlign: 'center',
  maxHeight: '80px'
},
    imgStyle = { //@TODO: remove this, img should be properly scaled once size is settled
  height: '80px'
};

var Header = React.createClass({
  displayName: 'Header',

  render: function render() {
    return React.createElement(
      'header',
      null,
      React.createElement(TopBar, null),
      React.createElement(
        'div',
        { style: logoStyle },
        React.createElement('img', { src: './img/lbry-dark-1600x528.png', style: imgStyle })
      )
    );
  }
});

var topBarStyle = {
  'float': 'right',
  'position': 'relative',
  'height': '26px'
},
    balanceStyle = {
  'marginRight': '5px'
};

var mainMenuStyle = {
  position: 'absolute',
  top: '26px',
  right: '0px'
};

var MainMenu = React.createClass({
  displayName: 'MainMenu',

  render: function render() {
    var isLinux = /linux/i.test(navigator.userAgent); // @TODO: find a way to use getVersionInfo() here without messy state management
    return React.createElement(
      'div',
      { style: mainMenuStyle },
      React.createElement(
        Menu,
        this.props,
        React.createElement(MenuItem, { href: '/?files', label: 'My Files', icon: 'icon-cloud-download' }),
        React.createElement(MenuItem, { href: '/?settings', label: 'Settings', icon: 'icon-gear' }),
        React.createElement(MenuItem, { href: '/?help', label: 'Help', icon: 'icon-question-circle' }),
        isLinux ? React.createElement(MenuItem, { href: '/?start', label: 'Exit LBRY', icon: 'icon-close' }) : null
      )
    );
  }
});

var TopBar = React.createClass({
  displayName: 'TopBar',

  getInitialState: function getInitialState() {
    return {
      balance: 0
    };
  },
  componentDidMount: function componentDidMount() {
    lbry.getBalance(function (balance) {
      this.setState({
        balance: balance
      });
    }.bind(this));
  },
  onClose: function onClose() {
    window.location.href = "?start";
  },
  render: function render() {
    return React.createElement(
      'span',
      { className: 'top-bar', style: topBarStyle },
      React.createElement(
        'span',
        { style: balanceStyle },
        React.createElement(CreditAmount, { amount: this.state.balance })
      ),
      React.createElement(Link, { ref: 'menuButton', title: 'LBRY Menu', icon: 'icon-bars' }),
      React.createElement(MainMenu, { toggleButton: this.refs.menuButton })
    );
  }
});

var HomePage = React.createClass({
  displayName: 'HomePage',

  componentDidMount: function componentDidMount() {
    lbry.getStartNotice(function (notice) {
      if (notice) {
        alert(notice);
      }
    });
  },
  render: function render() {
    return React.createElement(
      'div',
      { className: 'page' },
      React.createElement(Header, null),
      React.createElement(Discover, null)
    );
  }
});