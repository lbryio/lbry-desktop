"use strict";

var PublishPage = React.createClass({
  displayName: "PublishPage",

  publish: function publish() {
    lbry.publish({
      name: this.refs.name,
      file_path: this.refs.filePath,
      bid: parseFloat(this.refs.bid)
    });
  },
  render: function render() {
    return React.createElement(
      "main",
      { className: "page" },
      React.createElement(SubPageLogo, null),
      React.createElement(
        "h1",
        null,
        "Publish"
      ),
      React.createElement(
        "section",
        null,
        React.createElement(
          "h4",
          null,
          "LBRY name"
        ),
        React.createElement(
          "div",
          { className: "help" },
          "What LBRY name would you like to claim for this file?"
        ),
        "lbry://",
        React.createElement("input", { type: "text", ref: "name" })
      ),
      React.createElement(
        "section",
        null,
        React.createElement(
          "h4",
          null,
          "Choose file"
        ),
        React.createElement(
          "div",
          { className: "help" },
          "Please choose the file you would like to upload to LBRY."
        ),
        React.createElement(
          "div",
          null,
          React.createElement("input", { type: "file", ref: "filePath" })
        )
      ),
      React.createElement(
        "section",
        null,
        React.createElement(
          "h4",
          null,
          "Bid amount"
        ),
        React.createElement(
          "div",
          { className: "help" },
          "How much would you like to bid for this name? You must bid at least ",
          React.createElement(
            "strong",
            null,
            "0.0"
          ),
          " to claim this name."
        ),
        React.createElement("input", { type: "text", ref: "bidAmount" }),
        " LBC"
      ),
      React.createElement(
        "section",
        null,
        React.createElement(Link, { button: "primary", label: "Publish", onClick: this.publish })
      ),
      React.createElement(
        "section",
        null,
        React.createElement(Link, { href: "/", label: "<< Return" })
      )
    );
  }
});