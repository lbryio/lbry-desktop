'use strict';

var publishNumberInputStyle = {
  width: '50px'
},
    publishFieldLabelStyle = {
  display: 'inline-block',
  width: '118px',
  textAlign: 'right',
  verticalAlign: 'top'
},
    publishFieldStyle = {
  width: '330px'
};

var PublishPage = React.createClass({
  displayName: 'PublishPage',

  publish: function publish() {
    var _this = this;

    var doPublish = function doPublish(metadata) {
      lbry.publish({
        name: _this.state.name,
        file_path: _this._tempFilePath,
        bid: parseFloat(_this.state.bid),
        metadata: metadata
      }, function (message) {
        _this.handlePublishSuccess(_this.state.name, _this.state.title);
        _this.setState({
          submitting: false
        });
      }, function (error) {
        _this.handlePublishError(error);
        _this.setState({
          submitting: false
        });
      });
    };

    this.setState({
      submitting: true
    });

    var metadata = {
      title: this.refs.meta_title.value,
      author: this.refs.meta_author.value,
      description: this.refs.meta_description.value,
      language: this.refs.meta_language.value,
      license: this.refs.meta_license.value
    };

    if (this.refs.meta_thumbnail.value) {
      metadata.thumbnail = this.refs.meta_thumbnail.value;
    }

    if (this.state.isFee) {
      lbry.getNewAddress(function (address) {
        metadata.fee = {
          'LBC': {
            amount: parseFloat(_this.state.fee),
            address: address
          }
        };

        doPublish(metadata);
      });
    } else {
      doPublish(metadata);
    }
  },
  getInitialState: function getInitialState() {
    this._tempFilePath = null;

    return {
      name: '',
      bid: '',
      nameResolved: false,
      claimValue: 0.0,
      fileInfo: null,
      uploadProgress: 0.0,
      uploaded: false,
      tempFileReady: false,
      submitting: false
    };
  },
  handlePublishSuccess: function handlePublishSuccess(name, title) {
    alert('Your file ' + title + ' has been published to LBRY at the address lbry://' + name + '!\n\n' + 'You will now be taken to your My Files page, where your newly published file should appear within a few minutes.');
    window.location = "?myfiles";
  },
  handlePublishError: function handlePublishError(error) {
    alert('The following error occurred when attempting to publish your file:\n\n' + error.message);
  },
  handleNameChange: function handleNameChange(event) {
    var _this2 = this;

    var name = event.target.value;

    if (!name) {
      this.setState({
        name: '',
        nameResolved: false
      });

      return;
    }

    lbry.resolveName(name, function (info) {
      if (!info) {
        _this2.setState({
          name: name,
          nameResolved: false
        });
      } else {
        lbry.search(name, function (results) {
          var claimValue = results[0].value;

          _this2.setState({
            name: name,
            nameResolved: true,
            claimValue: parseFloat(claimValue)
          });
        });
      }
    });
  },
  handleBidChange: function handleBidChange(event) {
    this.setState({
      bid: event.target.value
    });
  },
  handleFeeChange: function handleFeeChange(event) {
    this.setState({
      fee: event.target.value
    });
  },
  handleFileChange: function handleFileChange(event) {
    var _this3 = this;

    event.preventDefault();

    var fileInput = event.target;

    this._tempFilePath = null;
    if (fileInput.files.length == 0) {
      // File was removed
      this.setState({
        fileInfo: null,
        uploadProgress: 0.0,
        uploaded: false,
        tempFileReady: false
      });
    } else {
      var file = fileInput.files[0];
      this.setState({
        fileInfo: {
          name: file.name,
          size: file.size
        },
        uploadProgress: 0.0,
        uploaded: false,
        tempFileReady: false
      });

      var xhr = new XMLHttpRequest();
      xhr.upload.addEventListener('progress', function (event) {
        _this3.setState({
          uploadProgress: event.loaded / event.total
        });
      });
      xhr.upload.addEventListener('load', function (event) {
        _this3.setState({
          uploaded: true
        });
      });
      xhr.addEventListener('load', function (event) {
        _this3._tempFilePath = JSON.parse(xhr.responseText);
        _this3.setState({
          tempFileReady: true
        });
      });

      xhr.open('POST', '/upload', true);
      xhr.send(new FormData(fileInput.form));
    }
  },
  handleFeePrefChange: function handleFeePrefChange(feeEnabled) {
    this.setState({
      isFee: feeEnabled
    });
  },
  readyToPublish: function readyToPublish() {
    var bidFloat = parseFloat(this.state.bid);
    return this.state.name && this.state.fileInfo && !isNaN(bidFloat) && (!this.state.claimValue || bidFloat > this.state.claimValue);
  },
  render: function render() {
    var _this4 = this;

    if (this.state.fileInfo && !this.state.tempFileReady) {
      // A file was chosen but the daemon hasn't finished processing it yet, i.e. it's loading, so
      // we need a value for the progress bar.

      if (!this.state.uploaded) {
        // Still uploading
        var progressOpts = {
          value: this.state.uploadProgress
        };
      } else {
        // Fully uploaded and waiting for server to finish processing, so set progress bar to "indeterminite"
        var progressOpts = {};
      }
    }

    return React.createElement(
      'main',
      { className: 'page' },
      React.createElement(SubPageLogo, null),
      React.createElement(
        'h1',
        null,
        'Publish Content'
      ),
      React.createElement(
        'section',
        null,
        React.createElement(
          'h4',
          null,
          'LBRY name'
        ),
        React.createElement(
          'div',
          { className: 'help' },
          'What LBRY name would you like to claim for this file?'
        ),
        'lbry://',
        React.createElement('input', { type: 'text', ref: 'name', onChange: this.handleNameChange }),
        !this.state.name ? '' : this.state.nameResolved ? React.createElement(
          'em',
          null,
          ' This name is currently claimed for ',
          React.createElement(
            'strong',
            null,
            lbry.formatCredits(this.state.claimValue)
          ),
          ' credits'
        ) : React.createElement(
          'em',
          null,
          ' This name is available'
        )
      ),
      React.createElement(
        'section',
        null,
        React.createElement(
          'h4',
          null,
          'Choose file'
        ),
        React.createElement(
          'form',
          null,
          React.createElement('input', { name: 'file', type: 'file', onChange: this.handleFileChange }),
          !this.state.fileInfo ? '' : !this.state.tempFileReady ? React.createElement(
            'div',
            null,
            React.createElement('progress', progressOpts),
            !this.state.uploaded ? React.createElement(
              'span',
              null,
              ' Importing file into LBRY...'
            ) : React.createElement(
              'span',
              null,
              ' Processing file...'
            )
          ) : React.createElement(
            'div',
            null,
            'File ready for publishing!'
          )
        )
      ),
      React.createElement(
        'section',
        null,
        React.createElement(
          'h4',
          null,
          'Bid amount'
        ),
        React.createElement(
          'section',
          { className: 'help' },
          'How much would you like to bid for this name?',
          !this.state.nameResolved ? React.createElement(
            'span',
            null,
            ' Since this name is not currently resolved, you may bid as low as you want, but higher bids help prevent others from claiming your name.'
          ) : React.createElement(
            'span',
            null,
            ' You must bid over ',
            React.createElement(
              'strong',
              null,
              lbry.formatCredits(this.state.claimValue)
            ),
            ' credits to claim this name.'
          )
        ),
        'Credits ',
        React.createElement('input', { style: publishNumberInputStyle, type: 'text', onChange: this.handleBidChange, value: this.state.bid, placeholder: this.state.nameResolved ? lbry.formatCredits(this.state.claimValue + 10) : 100 }),
        this.state.bid && isNaN(this.state.bid) ? React.createElement(
          'span',
          { className: 'warning' },
          ' Must be a number'
        ) : ''
      ),
      React.createElement(
        'section',
        null,
        React.createElement(
          'h4',
          null,
          'Fee'
        ),
        React.createElement(
          'section',
          { className: 'help' },
          'How much would you like to charge for this file? '
        ),
        React.createElement(
          'label',
          { style: settingsRadioOptionStyles },
          React.createElement('input', { type: 'radio', onChange: function onChange() {
              _this4.handleFeePrefChange(false);
            }, checked: !this.state.isFee }),
          ' No fee'
        ),
        React.createElement(
          'label',
          { style: settingsRadioOptionStyles },
          React.createElement('input', { type: 'radio', onChange: function onChange() {
              _this4.handleFeePrefChange(true);
            }, checked: this.state.isFee }),
          ' ',
          !this.state.isFee ? 'Choose fee...' : 'Fee (in LBRY credits) ',
          React.createElement('input', { className: this.state.isFee ? '' : 'hidden ', onChange: this.handleFeeChange, placeholder: '5.5', style: publishNumberInputStyle }),
          this.state.fee && isNaN(this.state.fee) ? React.createElement(
            'span',
            { className: 'warning' },
            ' Must be a number'
          ) : ''
        )
      ),
      React.createElement(
        'section',
        null,
        React.createElement(
          'h4',
          null,
          'Your content'
        ),
        React.createElement(
          'section',
          null,
          React.createElement(
            'label',
            { 'for': 'title', style: publishFieldLabelStyle },
            'Title'
          ),
          ' ',
          React.createElement('input', { ref: 'meta_title', name: 'title', placeholder: 'My Show, Episode 1', style: publishFieldStyle })
        ),
        React.createElement(
          'section',
          null,
          React.createElement(
            'label',
            { 'for': 'author', style: publishFieldLabelStyle },
            'Author'
          ),
          ' ',
          React.createElement('input', { ref: 'meta_author', name: 'author', placeholder: 'My Company, Inc.', style: publishFieldStyle })
        ),
        React.createElement(
          'section',
          null,
          React.createElement(
            'label',
            { 'for': 'license', style: publishFieldLabelStyle },
            'License info'
          ),
          ' ',
          React.createElement('input', { ref: 'meta_license', name: 'license', placeholder: 'Copyright My Company, Inc. ' + new Date().getFullYear() + '.', style: publishFieldStyle })
        ),
        React.createElement(
          'section',
          null,
          React.createElement(
            'label',
            { 'for': 'language', style: publishFieldLabelStyle },
            'Language'
          ),
          ' ',
          React.createElement(
            'select',
            { ref: 'meta_language', name: 'language' },
            React.createElement(
              'option',
              { value: 'en', selected: true },
              'English'
            ),
            React.createElement(
              'option',
              { value: 'zh' },
              'Chinese'
            ),
            React.createElement(
              'option',
              { value: 'fr' },
              'French'
            ),
            React.createElement(
              'option',
              { value: 'de' },
              'German'
            ),
            React.createElement(
              'option',
              { value: 'jp' },
              'Japanese'
            ),
            React.createElement(
              'option',
              { value: 'ru' },
              'Russian'
            ),
            React.createElement(
              'option',
              { value: 'es' },
              'Spanish'
            )
          )
        ),
        React.createElement(
          'section',
          null,
          React.createElement(
            'label',
            { 'for': 'description', style: publishFieldLabelStyle },
            'Description'
          ),
          ' ',
          React.createElement('textarea', { ref: 'meta_description', name: 'description', placeholder: 'Description of your content', style: publishFieldStyle })
        )
      ),
      React.createElement(
        'h4',
        null,
        'Additional content information (optional)'
      ),
      React.createElement(
        'section',
        null,
        React.createElement(
          'label',
          { 'for': 'meta_thumbnail', style: publishFieldLabelStyle },
          'Thumbnail URL'
        ),
        ' ',
        React.createElement('input', { ref: 'meta_thumbnail', name: 'thumbnail', placeholder: 'http://mycompany.com/images/ep_1.jpg', style: publishFieldStyle })
      ),
      React.createElement(
        'section',
        null,
        React.createElement(Link, { button: 'primary', label: 'Publish', onClick: this.publish, disabled: !this.readyToPublish() || this.state.submitting })
      ),
      React.createElement(
        'section',
        null,
        React.createElement(Link, { href: '/', label: '<< Return' })
      )
    );
  }
});