'use strict';

var removeIconColumnStyle = {
  fontSize: '1.3em',
  height: '120px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center'
},
    progressBarStyle = {
  height: '15px',
  width: '230px',
  backgroundColor: '#444',
  border: '2px solid #eee',
  display: 'inline-block'
},
    myFilesRowImgStyle = {
  maxHeight: '100px',
  display: 'block',
  marginLeft: 'auto',
  marginRight: 'auto'
};

var MyFilesRow = React.createClass({
  displayName: 'MyFilesRow',

  onRemoveClicked: function onRemoveClicked() {
    var alertText = 'Are you sure you\'d like to remove "' + this.props.title + '?" This will ' + (this.completed ? ' stop the download and ' : '') + 'permanently remove the file from your system.';

    if (confirm(alertText)) {
      lbry.deleteFile(this.props.lbryUri);
    }
  },
  onPauseResumeClicked: function onPauseResumeClicked() {
    if (this.props.stopped) {
      lbry.startFile(this.props.lbryUri);
    } else {
      lbry.stopFile(this.props.lbryUri);
    }
  },
  render: function render() {
    var _this = this;

    var progressBarWidth = 230; // Move this somewhere better

    if (this.props.completed) {
      var pauseLink = null;
      var curProgressBarStyle = { display: 'none' };
    } else {
      var pauseLink = React.createElement(Link, { icon: this.props.stopped ? 'icon-play' : 'icon-pause',
        label: this.props.stopped ? 'Resume download' : 'Pause download',
        onClick: function onClick() {
          _this.onPauseResumeClicked();
        } });

      var curProgressBarStyle = Object.assign({}, progressBarStyle);
      curProgressBarStyle.width = Math.floor(this.props.ratioLoaded * progressBarWidth) + 'px';
      curProgressBarStyle.borderRightWidth = progressBarWidth - Math.ceil(this.props.ratioLoaded * progressBarWidth) + 2;
    }

    if (this.props.showWatchButton) {
      var watchButton = React.createElement(WatchLink, { streamName: this.props.lbryUri });
    } else {
      var watchButton = null;
    }

    return React.createElement(
      'div',
      { className: 'row-fluid' },
      React.createElement(
        'div',
        { className: 'span3' },
        React.createElement('img', { src: this.props.imgUrl, alt: 'Photo for ' + this.props.title, style: myFilesRowImgStyle })
      ),
      React.createElement(
        'div',
        { className: 'span6' },
        React.createElement(
          'h2',
          null,
          this.props.title
        ),
        React.createElement('div', { className: this.props.completed ? 'hidden' : '', style: curProgressBarStyle }),
        ' ',
        this.props.completed ? 'Download complete' : parseInt(this.props.ratioLoaded * 100) + '%',
        React.createElement(
          'div',
          null,
          pauseLink
        ),
        React.createElement(
          'div',
          null,
          watchButton
        )
      ),
      React.createElement(
        'div',
        { className: 'span1', style: removeIconColumnStyle },
        React.createElement(Link, { icon: 'icon-close', title: 'Remove file', onClick: function onClick() {
            _this.onRemoveClicked();
          } }),
        React.createElement('br', null)
      )
    );
  }
});

var MyFilesPage = React.createClass({
  displayName: 'MyFilesPage',

  getInitialState: function getInitialState() {
    return {
      filesInfo: null
    };
  },
  componentWillMount: function componentWillMount() {
    this.updateFilesInfo();
  },
  updateFilesInfo: function updateFilesInfo() {
    var _this2 = this;

    lbry.getFilesInfo(function (filesInfo) {
      _this2.setState({
        filesInfo: filesInfo ? filesInfo : []
      });
      setTimeout(function () {
        _this2.updateFilesInfo();
      }, 1000);
    });
  },
  render: function render() {
    if (this.state.filesInfo === null) {
      return null;
    }

    if (!this.state.filesInfo.length) {
      var content = React.createElement(
        'span',
        null,
        'You haven\'t downloaded anything from LBRY yet. Go ',
        React.createElement(Link, { href: '/', label: 'search for your first download' }),
        '!'
      );
    } else {
      var content = [];
      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = this.state.filesInfo[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var fileInfo = _step.value;
          var completed = fileInfo.completed;
          var written_bytes = fileInfo.written_bytes;
          var total_bytes = fileInfo.total_bytes;
          var lbry_uri = fileInfo.lbry_uri;
          var file_name = fileInfo.file_name;
          var stopped = fileInfo.stopped;
          var metadata = fileInfo.metadata;
          var name = metadata.name;
          var stream_name = metadata.stream_name;
          var thumbnail = metadata.thumbnail;


          var title = name || stream_name || 'lbry://' + lbry_uri;
          var ratioLoaded = written_bytes / total_bytes;
          var showWatchButton = lbry.getMediaType(file_name) == 'video';

          content.push(React.createElement(MyFilesRow, { lbryUri: lbry_uri, title: title, completed: completed, stopped: stopped,
            ratioLoaded: ratioLoaded, imgUrl: thumbnail,
            showWatchButton: showWatchButton }));
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator.return) {
            _iterator.return();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }
    }
    return React.createElement(
      'main',
      { className: 'page' },
      React.createElement(SubPageLogo, null),
      React.createElement(
        'h1',
        null,
        'My files'
      ),
      React.createElement(
        'section',
        null,
        content
      ),
      React.createElement(
        'section',
        null,
        React.createElement(Link, { href: '/', label: '<< Return' })
      )
    );
  }
});