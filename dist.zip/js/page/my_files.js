'use strict';

var MyFilesCellStyle = {
  padding: '3px',
  border: '2px solid black'
};

var MyFilesRow = React.createClass({
  displayName: 'MyFilesRow',

  render: function render() {
    return React.createElement(
      'tr',
      null,
      React.createElement(
        'td',
        { style: MyFilesCellStyle },
        this.props.streamName
      ),
      React.createElement(
        'td',
        { style: MyFilesCellStyle },
        this.props.completed ? 'True' : 'False'
      ),
      React.createElement(
        'td',
        { style: MyFilesCellStyle },
        React.createElement(Link, { label: this.props.stopped ? 'Start' : 'Stop' })
      ),
      React.createElement(
        'td',
        { style: MyFilesCellStyle },
        React.createElement(Link, { label: 'Cancel' })
      )
    );
  }
});

var MyFilesPage = React.createClass({
  displayName: 'MyFilesPage',

  getInitialState: function getInitialState() {
    return {
      filesInfo: null
    };
  },
  componentWillMount: function componentWillMount() {
    var _this = this;

    lbry.getFilesInfo(function (filesInfo) {
      _this.setState({
        filesInfo: filesInfo
      });
    });
  },
  render: function render() {
    if (!this.state.filesInfo) {
      return null;
    } else {
      var rows = [];
      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = this.state.filesInfo[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var fileInfo = _step.value;

          console.log(fileInfo);
          rows.push(React.createElement(MyFilesRow, { streamName: fileInfo.stream_name, completed: fileInfo.completed }));
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator.return) {
            _iterator.return();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }

      console.log(rows);
      return React.createElement(
        'main',
        null,
        React.createElement(
          'h1',
          null,
          'My files'
        ),
        React.createElement(
          'table',
          null,
          React.createElement(
            'thead',
            null,
            React.createElement(
              'tr',
              null,
              React.createElement(
                'th',
                { style: MyFilesCellStyle },
                'Stream name'
              ),
              React.createElement(
                'th',
                { style: MyFilesCellStyle },
                'Completed'
              ),
              React.createElement(
                'th',
                { style: MyFilesCellStyle },
                'Toggle'
              ),
              React.createElement(
                'th',
                { style: MyFilesCellStyle },
                'Remove'
              )
            )
          ),
          React.createElement(
            'tbody',
            null,
            rows
          )
        ),
        React.createElement(
          'section',
          null,
          React.createElement(Link, { href: '/', label: '<< Return' })
        )
      );
    }
  }
});