"use strict";

var StartPage = React.createClass({
  displayName: "StartPage",

  render: function render() {
    return React.createElement(
      "main",
      null,
      React.createElement(
        "h1",
        null,
        "LBRY is not running"
      ),
      React.createElement(
        "section",
        null,
        React.createElement(Link, { href: "/", label: "Start LBRY" })
      )
    );
  }
});