'use strict';

var formatItemStyle = {
  fontSize: '0.95em',
  marginTop: '10px',
  maxHeight: '220px'
},
    formatItemImgStyle = {
  maxWidth: '100%',
  maxHeight: '100%',
  display: 'block',
  marginLeft: 'auto',
  marginRight: 'auto',
  marginTop: '5px'
},
    formatHeaderStyle = {
  fontWeight: 'bold',
  marginBottom: '5px'
},
    formatSubheaderStyle = {
  marginBottom: '10px',
  fontSize: '0.9em'
},
    formatItemDescriptionStyle = {
  color: '#444',
  marginBottom: '5px',
  fontSize: '1.2em'
},
    formatItemMetadataStyle = {
  color: '#444',
  marginBottom: '5px',
  fontSize: '0.9em'
},
    formatItemCostStyle = {
  float: 'right'
};

var FormatItem = React.createClass({
  displayName: 'FormatItem',

  propTypes: {
    results: React.PropTypes.object
  },
  render: function render() {
    var results = this.props.results;
    var name = results.name;
    var thumbnail = results.thumbnail;
    var title = results.title;
    var amount = results.cost_est ? results.cost_est : 0.0;
    var description = results.description;
    var author = results.author;
    var language = results.language;
    var license = results.license;
    var fileContentType = results['content-type'];

    return React.createElement(
      'div',
      { className: 'row-fluid', style: formatItemStyle },
      React.createElement(
        'div',
        { className: 'span4' },
        React.createElement('img', { src: thumbnail, alt: 'Photo for ' + title, style: formatItemImgStyle })
      ),
      React.createElement(
        'div',
        { className: 'span8' },
        React.createElement(
          'h4',
          { style: formatItemMetadataStyle },
          React.createElement(
            'b',
            null,
            'Address:'
          ),
          ' ',
          name
        ),
        React.createElement(
          'h4',
          { style: formatItemMetadataStyle },
          React.createElement(
            'b',
            null,
            'Content-Type:'
          ),
          ' ',
          fileContentType
        ),
        React.createElement(
          'div',
          { style: formatSubheaderStyle },
          React.createElement(
            'div',
            { style: formatItemCostStyle },
            React.createElement(CreditAmount, { amount: amount, isEstimate: true })
          ),
          React.createElement(WatchLink, { streamName: name }),
          '   ',
          React.createElement(DownloadLink, { streamName: name })
        ),
        React.createElement(
          'p',
          { style: formatItemDescriptionStyle },
          description
        ),
        React.createElement(
          'div',
          null,
          React.createElement(
            'span',
            { style: formatItemMetadataStyle },
            React.createElement(
              'b',
              null,
              'Author:'
            ),
            ' ',
            author
          ),
          React.createElement('br', null),
          React.createElement(
            'span',
            { style: formatItemMetadataStyle },
            React.createElement(
              'b',
              null,
              'Language:'
            ),
            ' ',
            language
          ),
          React.createElement('br', null),
          React.createElement(
            'span',
            { style: formatItemMetadataStyle },
            React.createElement(
              'b',
              null,
              'License:'
            ),
            ' ',
            license
          ),
          React.createElement('br', null)
        )
      )
    );
  }
});

var FormatsSection = React.createClass({
  displayName: 'FormatsSection',

  propTypes: {
    results: React.PropTypes.object,
    name: React.PropTypes.string
  },
  render: function render() {
    var name = this.props.name;
    var format = this.props.results;
    var title = format.title;

    if (format == null) {
      return React.createElement(
        'div',
        null,
        React.createElement(
          'h1',
          { style: formatHeaderStyle },
          'Sorry, no results found for "',
          name,
          '".'
        )
      );
    }

    return React.createElement(
      'div',
      null,
      React.createElement(
        'h1',
        { style: formatHeaderStyle },
        title
      ),
      React.createElement(FormatItem, { results: format })
    );
  }
});

var DetailPage = React.createClass({
  displayName: 'DetailPage',

  propTypes: {
    name: React.PropTypes.string
  },
  getInitialState: function getInitialState() {
    return {
      results: null,
      searching: true
    };
  },
  componentWillMount: function componentWillMount() {
    var _this = this;

    lbry.search(this.props.name, function (results) {
      _this.setState({
        results: results[0],
        searching: false
      });
    });
  },
  render: function render() {
    if (this.state.results == null && this.state.searching) {
      // Still waiting for metadata
      return null;
    }

    var name = this.props.name;
    var metadata = this.state.metadata;
    var results = this.state.results;

    return React.createElement(
      'main',
      { className: 'page' },
      React.createElement(SubPageLogo, null),
      React.createElement(FormatsSection, { name: name, results: results }),
      React.createElement(
        'section',
        null,
        React.createElement(Link, { href: '/', label: '<< Return' })
      )
    );
  }
});