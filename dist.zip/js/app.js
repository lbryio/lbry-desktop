'use strict';

var appStyles = {
  width: '800px',
  marginLeft: 'auto',
  marginRight: 'auto'
};
var App = React.createClass({
  displayName: 'App',

  getInitialState: function getInitialState() {
    return {
      viewingPage: window.location.search === '?settings' ? 'settings' : 'home'
    };
  },
  componentDidMount: function componentDidMount() {
    lbry.getStartNotice(function (notice) {
      if (notice) {
        alert(notice);
      }
    });
  },
  render: function render() {
    if (this.state.viewingPage == 'home') {
      var content = React.createElement(HomePage, null);
    } else if (this.state.viewingPage == 'settings') {
      var content = React.createElement(SettingsPage, null);
    }
    return React.createElement(
      'div',
      { style: appStyles },
      content
    );
  }
});