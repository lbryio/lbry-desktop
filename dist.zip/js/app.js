'use strict';

var _slicedToArray = function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"]) _i["return"](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError("Invalid attempt to destructure non-iterable instance"); } }; }();

var appStyles = {
  width: '800px',
  marginLeft: 'auto',
  marginRight: 'auto'
};
var App = React.createClass({
  displayName: 'App',

  getInitialState: function getInitialState() {
    // For now, routes are in format ?page or ?page=args
    var match, param, val;

    var _window$location$sear = window.location.search.match(/\??([^=]*)(?:=(.*))?/);

    var _window$location$sear2 = _slicedToArray(_window$location$sear, 3);

    match = _window$location$sear2[0];
    param = _window$location$sear2[1];
    val = _window$location$sear2[2];


    if (['settings', 'help', 'start', 'watch'].indexOf(param) != -1) {
      var viewingPage = param;
    } else {
      var viewingPage = 'home';
    }

    return {
      viewingPage: viewingPage,
      pageArgs: val
    };
  },
  componentWillMount: function componentWillMount() {
    lbry.checkNewVersionAvailable(function (isAvailable) {
      if (isAvailable) {
        var message = "The version of LBRY you're using is not up to date.\n\n" + "You'll now be taken to lbry.io, where you can download the latest version.";

        lbry.getVersionInfo(function (versionInfo) {
          var maj, min, patch;

          var _versionInfo$lbrynet_ = versionInfo.lbrynet_version.split('.');

          var _versionInfo$lbrynet_2 = _slicedToArray(_versionInfo$lbrynet_, 3);

          maj = _versionInfo$lbrynet_2[0];
          min = _versionInfo$lbrynet_2[1];
          patch = _versionInfo$lbrynet_2[2];


          if (versionInfo.os_system == 'Darwin' && maj == 0 && min <= 2 && patch <= 2) {
            // On OS X with version <= 0.2.2, we need to notify user to close manually close LBRY
            message += "\n\nBefore installing the new version, make sure to exit LBRY, if you started the app " + "click that LBRY icon in your status bar and choose \"Quit.\"";
          } else {
            lbry.stop();
          }

          alert(message);
          window.location = "http://www.lbry.io/" + (versionInfo.os_system == 'Darwin' ? 'osx' : 'linux');
        });
      }
    });
  },
  componentDidMount: function componentDidMount() {
    lbry.getStartNotice(function (notice) {
      if (notice) {
        alert(notice);
      }
    });
  },
  render: function render() {
    if (this.state.viewingPage == 'home') {
      var content = React.createElement(HomePage, null);
    } else if (this.state.viewingPage == 'settings') {
      var content = React.createElement(SettingsPage, null);
    } else if (this.state.viewingPage == 'help') {
      var content = React.createElement(HelpPage, null);
    } else if (this.state.viewingPage == 'watch') {
      var content = React.createElement(WatchPage, { name: this.state.pageArgs });
    } else if (this.state.viewingPage == 'start') {
      var content = React.createElement(StartPage, null);
    }
    return React.createElement(
      'div',
      { style: appStyles },
      content
    );
  }
});